package com.example.actividadclase

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.actividadclase.ui.theme.ActividadClaseTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView (R.layout.activity_inicial)

        val campoValorPropiedad: EditText = findViewById(R.id.Valor_propiedad)
        val campoValorPrestamo: EditText = findViewById(R.id.Valor_Prestamo)
        val campoValorAños: EditText = findViewById(R.id.Valor_años)
        val campoTAE: EditText = findViewById(R.id.valor_Tasa)
        val campoResultado: TextView = findViewById(R.id.Cuota)
        val buttoncalcular = findViewById<Button>(R.id.Simular)

        buttoncalcular.setOnClickListener {
            val valorPropiedad = campoValorPropiedad.text.toString().toIntOrNull()
            val vp = campoValorPrestamo.text.toString().toIntOrNull()
            val n = campoValorAños.text.toString().toIntOrNull()
            val tasaInteres = campoTAE.text.toString().toDoubleOrNull()

            fun Double.pow(exp: Int): Double {
                return Math.pow(this, exp.toDouble())
            }

            if (valorPropiedad >= 70000000){
            val porcentaje = valorPropiedad*0.70
            if(vp >= 50000000 && vp <= porcentaje){
                if(5 <= n && n <= 20){
                    val nMeses = n*12
                    if (tasaInteres >= 12.0 && tasaInteres <= 24.9) {
                        val i = (tasaInteres / 12) / 100
                        val cuota = vp * (((1 + i).pow(nMeses) * i) / ((1 + i).pow(nMeses) - 1))
                        campoResultado.text= "Paga cuotas de ${"%-2f".format(cuota)} por mes"
                    }
                }
            }

        }


}
